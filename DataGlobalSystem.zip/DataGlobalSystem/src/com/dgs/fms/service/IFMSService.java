package com.dgs.fms.service;

import java.util.List;

import com.dgs.fms.dto.CourseMaster;
import com.dgs.fms.dto.DemoView;
import com.dgs.fms.dto.EmployeeMaster;
import com.dgs.fms.dto.FacultySkillView;
import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;

public interface IFMSService {
	public int insertFeedback(FeedbackMaster feedback) throws FMSException;
	public EmployeeMaster matchLogin(String employeeName) throws FMSException; 
	public List<DemoView> showMonthlyFeedback(String month) throws FMSException;
	public boolean deleteFacultyRecord(int id) throws FMSException;
	public List<FacultySkillView> mapFacultySkills() throws FMSException;
	public int updateFacultySkill(String courselist,int facultyid) throws FMSException;
	public List<CourseMaster> mapCourseSkills() throws FMSException;
	public int insertCourseRecord(String courseName,int noOfDays) throws FMSException;
	public int updateCourseList(int courseid,int noofdays) throws FMSException;

}
