package com.dgs.fms.service;

import java.util.List;

import com.dgs.fms.dao.FMSDaoImpl;
import com.dgs.fms.dao.IFMSDao;
import com.dgs.fms.dto.CourseMaster;
import com.dgs.fms.dto.DemoView;
import com.dgs.fms.dto.EmployeeMaster;
import com.dgs.fms.dto.FacultySkillView;
import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;

public class FMSServiceImpl implements IFMSService {

	EmployeeMaster emp=new EmployeeMaster();
	IFMSDao daoService=new FMSDaoImpl();
	@Override
	public int insertFeedback(FeedbackMaster feedback) throws FMSException {
		return daoService.insertFeedback(feedback);
	}
	@Override
	public EmployeeMaster matchLogin(String employeeName) throws FMSException {
		
		return daoService.matchLogin(employeeName);
	}
	@Override
	public List<DemoView> showMonthlyFeedback(String month) throws FMSException {
		
		return daoService.showMonthlyFeedback(month);
	}
	
	public List<FacultySkillView> mapFacultySkills() throws FMSException{
		 return daoService.mapFacultySkills();
	
	}
	@Override
	public boolean deleteFacultyRecord(int id) throws FMSException {
		
		return daoService.deleteFacultyRecord(id);
	}
	@Override
	public int updateFacultySkill(String courselist,int facultyid) throws FMSException {
		
		return daoService.updateFacultySkill(courselist,facultyid);
	}
	@Override
	public List<CourseMaster> mapCourseSkills() throws FMSException {
		
		return daoService.mapCourseSkills();
	}

	@Override
	public int updateCourseList(int courseid, int noofdays) throws FMSException {
		
		return daoService.updateCourseList(courseid, noofdays);
	}
	@Override
	public int insertCourseRecord(String courseName,int noOfDays) throws FMSException {
		
		return daoService.insertCourseRecord(courseName,noOfDays);
	}

}
