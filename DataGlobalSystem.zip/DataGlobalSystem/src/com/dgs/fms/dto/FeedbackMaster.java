package com.dgs.fms.dto;

public class FeedbackMaster {

	private int trainingCode;
	private int participantId;
	private int fbPrsComm;
	private int fbClrfyDbts;
	private int fbTm;
	private int fbHndOut;
	private int fbHwSwNtwrk;
	public int getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	public int getParticipantId() {
		return participantId;
	}
	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}
	public int getFbPrsComm() {
		return fbPrsComm;
	}
	public void setFbPrsComm(int fbPrsComm) {
		this.fbPrsComm = fbPrsComm;
	}
	
	public int getFbClrfyDbts() {
		return fbClrfyDbts;
	}
	public void setFbClrfyDbts(int fbClrfyDbts) {
		this.fbClrfyDbts = fbClrfyDbts;
	}
	public int getFbTm() {
		return fbTm;
	}
	public void setFbTm(int fbTm) {
		this.fbTm = fbTm;
	}
	public int getFbHndOut() {
		return fbHndOut;
	}
	public void setFbHndOut(int fbHndOut) {
		this.fbHndOut = fbHndOut;
	}
	public int getFbHwSwNtwrk() {
		return fbHwSwNtwrk;
	}
	public void setFbHwSwNtwrk(int fbHwSwNtwrk) {
		this.fbHwSwNtwrk = fbHwSwNtwrk;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestions() {
		return suggestions;
	}
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}
	private String comments;
	private String suggestions;
	
}
