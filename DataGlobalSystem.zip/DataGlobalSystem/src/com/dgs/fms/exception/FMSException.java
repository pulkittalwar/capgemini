package com.dgs.fms.exception;

public class FMSException extends Exception {

	public FMSException(String msg){
		super(msg);
	}
}
