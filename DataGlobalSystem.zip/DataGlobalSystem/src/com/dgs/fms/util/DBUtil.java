package com.dgs.fms.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.dgs.fms.exception.FMSException;

public  class DBUtil {

	static Connection connection;

	public static Connection getConnection() throws FMSException {
		
			try {
				InitialContext context = new InitialContext();
				DataSource source = (DataSource) context.lookup("java:/oracleDs");
				connection = source.getConnection();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		return connection;
	}
}
